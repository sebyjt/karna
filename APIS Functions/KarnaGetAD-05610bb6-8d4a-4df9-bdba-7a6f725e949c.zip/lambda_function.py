import boto3
import random
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("karnaUserDetails")
    db_response = DB.get_item(Key={"Username":event["Username"]})
    DB = dynamodb.Table("KarnaCustomAds")
    adList = DB.scan()
    adList=adList["Items"]
    print(db_response)
    print(adList)
    try:
        Data=db_response["Item"]
        percentage=int(Data["Percentage"])/100
        print(percentage)
        if percentage<0.2:
            Num=random.randint(0,100)
            if(Num<80):
                ad=adList[0]
            else:
                ad=adList[1]
        elif percentage<0.75:
            Num=random.randint(0,100)
            print("Random Number",Num)
            if(Num<80):
                ad=adList[1]
            else:
                ad=adList[2]
        elif percentage<0.90:
            Num=random.randint(0,100)
            print("Random Number",Num)
            if(Num<80):
                ad=adList[2]
            else:
                ad=adList[1]
        elif percentage>0.90:
            print(adList)
            ad=adList[2]
        else:
            ad=adList[3]
        return ad
    except Exception as e:
        print(e)
        return {"Message":"user not found"}
    
