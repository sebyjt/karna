import boto3
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("karnaUserDetails")
    AdDB=dynamodb.Table("KarnaCustomAds")
    try:
        db_response = DB.get_item(Key={"Username":event["Username"]})
        print(db_response)
        ad_response=AdDB.get_item(Key={"ADS_ID":event["ADS_ID"]})
        ad_response=ad_response["Item"]
        Price=float(ad_response["Price"])
        db_resquest=db_response["Item"]
        adsViewed=int(db_resquest["AdsViewed"])
        Percentage=float(db_resquest["Percentage"])/100
        if(Percentage>0.9):
            Multiplier=1
        else:
            Multiplier=Percentage*Price
        try:
            MoneyGained=float(db_resquest["MoneyGained"])
            MoneyDonated=float(db_resquest["MoneyDonated"])
            MoneyGenerated=float(db_resquest["MoneyGenerated"])
        except Exception as e:
            MoneyGenerated=0
            print(e)
        print("Money Generated",MoneyGenerated)
        db_resquest['AdsViewed']=str(adsViewed+1)
        adsViewed=float(db_resquest['AdsViewed'])
        db_resquest['MoneyGenerated']=str(round(MoneyGenerated+adsViewed*Multiplier,2))
        db_resquest['MoneyGained']=str(round(float(db_resquest['MoneyGenerated'])*0.2,2))
        db_resquest['MoneyDonated']=str(round(float(db_resquest['MoneyGenerated'])*0.8,2))
        DB.put_item(Item=db_resquest)
        return {"Data":db_resquest}
    except Exception as e:
        # db_resquest={"Username":event["Username"],'AdsViewed':"1"}
        # DB.put_item(Item=db_resquest)
        print("Exception",e)
        return e