import boto3
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("KarnaSettings")
    db_response = DB.scan()
    print(db_response)
    return {"Data":db_response["Items"]}
