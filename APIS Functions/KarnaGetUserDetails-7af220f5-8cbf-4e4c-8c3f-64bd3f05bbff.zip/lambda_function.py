import boto3
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("karnaUserDetails")
    db_response = DB.get_item(Key={"Username":event["Username"]})
    print(db_response)
    try:
        return {"Data":db_response["Item"]}
    except Exception as e:
        print(e)
        return {"Message":"user not found"}
    
