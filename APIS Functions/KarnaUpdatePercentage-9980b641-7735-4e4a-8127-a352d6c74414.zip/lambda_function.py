import boto3
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("karnaUserDetails")
    db_response = DB.get_item(Key={"Username":event["Username"]})
    print(db_response)
    try:
        item=db_response["Item"]
        item["Percentage"]=event["Percentage"]
        print(item)
        DB.put_item(Item=item)
        return item
    except Exception as e:
        print(e)
        return {"Message":"user not found"}