import boto3
def Donated(json):
    try:
        # Also convert to int since update_time will be string.  When comparing
        # strings, "10" is smaller than "2".
        return float(json['MoneyDonated'])
    except KeyError:
        return 0
def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    DB = dynamodb.Table("karnaUserDetails")
    db_response = DB.scan()
    print(db_response)
    try:
        data=db_response["Items"]
        print(data)
        data.sort(key=Donated,reverse=True)
        print(data)
        for i in range(len(data)):
            data[i]["Rank"]=i+1
        return data
    except Exception as e:
        print(e)
        return {"Error in DB"}